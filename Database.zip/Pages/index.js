import { useState } from 'react'
import styles from '../styles/Home.module.css'

export default function Home() {
  const [message, setMessage] = useState('')

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Welcome to Database Project</h1>
      <p className={styles.description}>
        This project is deployed correctly on Vercel with Next.js!
      </p>
      <p className={styles.description}>Say anything below:</p>
      <input
        type="text"
        placeholder="Type here..."
        className={styles.inputField}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      {message && (
        <p className={styles.echo}>You said: {message}</p>
      )}
    </div>
  )
}